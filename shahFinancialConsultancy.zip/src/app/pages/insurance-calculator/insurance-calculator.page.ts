import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-insurance-calculator',
  templateUrl: './insurance-calculator.page.html',
  styleUrls: ['./insurance-calculator.page.scss'],
})
export class InsuranceCalculatorPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
